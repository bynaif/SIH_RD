"""FastAPI application for SIH-26038."""

from __future__ import annotations

import base64
import io
from pathlib import Path

import torch
from fastapi import FastAPI, File, HTTPException, UploadFile
from PIL import Image

from app.inference.gradcam import GradCAM
from app.inference.model_loader import load_model
from app.inference.quality_pipeline import prepare_quality_aware_image
from app.inference.predictor import (
    DR_LABELS,
    IMAGE_SIZE,
    LESION_LABELS,
    LESION_TYPES,
    build_inference_transform,
)
from training.quality import compute_quality_features


app = FastAPI(
    title="SIH-26038 Diabetic Retinopathy Screening API",
    version="0.1.0",
)


MODEL = None
MODEL_METADATA = None
DEVICE = None
GRADCAM = None


REFERABLE_THRESHOLD = 0.05
REFERABLE_THRESHOLD_SOURCE = (
    "E9 pooled validation selection"
)

# Frozen E9 post-hoc validation parameters.
CALIBRATION_TEMPERATURE = 2.069366
CONFORMAL_THRESHOLD = 0.812996
EVIDENCE_THRESHOLD = 0.238935
CONFORMAL_SOURCE = (
    "E9 pooled validation calibration"
)
EVIDENCE_THRESHOLD_SOURCE = (
    "E9 pooled validation calibration"
)


@app.on_event("startup")
def startup_event():
    global MODEL
    global MODEL_METADATA
    global DEVICE
    global GRADCAM

    MODEL, MODEL_METADATA = load_model()
    DEVICE = torch.device(MODEL_METADATA["device"])
    GRADCAM = GradCAM(MODEL)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_loaded": MODEL is not None,
        "gradcam_loaded": GRADCAM is not None,
        "model_experiment": (
            MODEL_METADATA["experiment"]
            if MODEL_METADATA
            else None
        ),
        "checkpoint_epoch": (
            MODEL_METADATA["epoch"]
            if MODEL_METADATA
            else None
        ),
        "device": str(DEVICE) if DEVICE else None,
    }


def _png_base64(image: Image.Image) -> str:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return base64.b64encode(
        buffer.getvalue()
    ).decode("ascii")


def _create_gradcam_overlay(
    pil_image: Image.Image,
    heatmap: torch.Tensor,
) -> str:
    """Create a model-attribution overlay, not a lesion map."""

    base = pil_image.resize(
        (IMAGE_SIZE, IMAGE_SIZE)
    )

    heatmap = heatmap.detach().cpu()

    if heatmap.ndim == 4:
        heatmap = heatmap[0, 0]
    elif heatmap.ndim == 3:
        heatmap = heatmap[0]

    heatmap_array = (
        heatmap.clamp(0.0, 1.0)
        .mul(255.0)
        .to(torch.uint8)
        .numpy()
    )

    heatmap_image = Image.fromarray(
        heatmap_array
    ).convert("L")

    red_map = Image.new(
        "RGBA",
        (IMAGE_SIZE, IMAGE_SIZE),
        (255, 0, 0, 0),
    )

    alpha = heatmap_image.point(
        lambda value: int(value * 0.55)
    )

    red_map.putalpha(alpha)

    overlay = base.convert("RGBA")
    overlay.alpha_composite(red_map)

    return _png_base64(
        overlay.convert("RGB")
    )


@app.post("/predict")
async def predict(
    image: UploadFile = File(...),
):
    if MODEL is None:
        raise HTTPException(
            status_code=503,
            detail="Model is not loaded.",
        )

    if GRADCAM is None:
        raise HTTPException(
            status_code=503,
            detail="Grad-CAM is not loaded.",
        )

    if not image.content_type or not image.content_type.startswith(
        "image/"
    ):
        raise HTTPException(
            status_code=400,
            detail="Uploaded file must be an image.",
        )

    try:
        image_bytes = await image.read()

        pil_image = Image.open(
            io.BytesIO(image_bytes)
        ).convert("RGB")

    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid image: {exc}",
        ) from exc

    # ---------------------------------------------------------
    # Image Quality Assessment
    #
    # These are deterministic image measurements only.
    # They are NOT clinical gradability labels.
    # ---------------------------------------------------------

    model_image, quality_features, quality_status = prepare_quality_aware_image(pil_image)

    # ---------------------------------------------------------
    # Model input
    # ---------------------------------------------------------

    transform = build_inference_transform()

    tensor = transform(
        model_image
    ).unsqueeze(0).to(DEVICE)

    # ---------------------------------------------------------
    # Main E9 prediction
    # ---------------------------------------------------------

    with torch.inference_mode():
        output = MODEL.forward_e8(
            tensor,
            output_size=(IMAGE_SIZE, IMAGE_SIZE),
        )

        # Post-hoc temperature calibration fitted on
        # pooled E9 validation predictions only.
        dr_probabilities = torch.softmax(
            output["dr_logits"]
            / CALIBRATION_TEMPERATURE,
            dim=1,
        )[0]

        dr_grade = int(
            torch.argmax(dr_probabilities).item()
        )

        dr_confidence = float(
            dr_probabilities[dr_grade].item()
        )

        referable_probability = float(
            torch.sigmoid(
                output["referable_logits"]
            )[0].item()
        )

        referable_prediction = (
            referable_probability
            >= REFERABLE_THRESHOLD
        )

        derived_referable = dr_grade >= 2

        # -----------------------------------------------------
        # Conformal prediction set
        # -----------------------------------------------------

        conformal_cutoff = (
            1.0 - CONFORMAL_THRESHOLD
        )

        conformal_set = [
            grade
            for grade in range(5)
            if float(dr_probabilities[grade].item())
            >= conformal_cutoff
        ]

        if not conformal_set:
            conformal_set = [dr_grade]

        if len(conformal_set) == 1:
            uncertainty_level = "low"
        elif len(conformal_set) <= 3:
            uncertainty_level = "moderate"
        else:
            uncertainty_level = "high"

        # -----------------------------------------------------
        # Experimental lesion map summaries
        # -----------------------------------------------------

        lesion_activations = {}

        for lesion in LESION_TYPES:
            lesion_activations[lesion] = float(
                torch.sigmoid(
                    output[f"{lesion}_logits"]
                ).mean().item()
            )

        # E7 evidence summary: robust upper-tail lesion
        # activation across the four experimental lesion heads.
        evidence_scores = []

        for lesion in LESION_TYPES:
            lesion_prob = torch.sigmoid(
                output[f"{lesion}_logits"]
            )

            flat = lesion_prob.flatten(
                start_dim=1
            )

            k = max(
                1,
                int(flat.shape[1] * 0.005),
            )

            evidence_scores.append(
                torch.topk(
                    flat,
                    k=k,
                    dim=1,
                ).values.mean(dim=1)
            )

        evidence_score = float(
            torch.stack(
                evidence_scores,
                dim=1,
            ).max(dim=1).values.item()
        )

        evidence_reliable = (
            evidence_score >= EVIDENCE_THRESHOLD
        )

        review_for_uncertainty = (
            len(conformal_set) > 1
        )

        review_for_evidence = (
            dr_grade >= 2
            and not evidence_reliable
        )

        review_required = (
            review_for_uncertainty
            or review_for_evidence
        )

        # Direct referable head and DR-grade-derived
        # referability are intentionally reported separately.
        referable_disagreement = (
            referable_prediction
            != derived_referable
        )
        review_required = review_required or referable_disagreement

    # ---------------------------------------------------------
    # Grad-CAM
    # ---------------------------------------------------------

    try:
        gradcam_result = GRADCAM.generate(
            tensor,
            target_class=dr_grade,
        )

        gradcam_overlay = _create_gradcam_overlay(
            model_image,
            gradcam_result["heatmap"],
        )

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Grad-CAM generation failed: {exc}",
        ) from exc

    return {
        "status": "reportable",

        "model": {
            "experiment": MODEL_METADATA["experiment"],
            "experiment_family": "E9",
            "checkpoint_id": Path(
                MODEL_METADATA["checkpoint"]
            ).name,
            "checkpoint_epoch": MODEL_METADATA["epoch"],
            "image_size": IMAGE_SIZE,
            "device": str(DEVICE),
        },

        "image_quality": {
            **quality_status,
            "action": "continue_with_caution",
            "recapture_required": quality_status.get("recapture_recommended", False),
            "enhancement": {
                "clahe": "experimental_clahe_luminance" in quality_status.get("enhancement_applied", []),
                "illumination_normalization": "bounded_illumination_normalization" in quality_status.get("enhancement_applied", []),
                "denoising": "experimental_median_denoise" in quality_status.get("enhancement_applied", []),
            },
            "focus": {
                "sharpness_laplacian_variance": quality_features.sharpness_laplacian_variance,
            },
            "illumination": {
                "mean_luminance": quality_features.mean_luminance,
                "luminance_stddev": quality_features.luminance_stddev,
                "luminance_p05": quality_features.luminance_p05,
                "luminance_p95": quality_features.luminance_p95,
                "illumination_nonuniformity": quality_features.illumination_nonuniformity,
                "dark_pixel_fraction": quality_features.dark_pixel_fraction,
                "saturated_pixel_fraction": quality_features.saturated_pixel_fraction,
            },
            "field_of_view": {
                "retinal_field_coverage": quality_features.retinal_field_coverage,
                "background_pixel_fraction": quality_features.background_pixel_fraction,
            },
            "features": quality_features.to_dict(),
        },

        "dr": {
            "grade": dr_grade,
            "label": DR_LABELS[dr_grade],
            "confidence": dr_confidence,
            "class_probabilities": [
                float(value.item())
                for value in dr_probabilities
            ],
        },

        "referable_dr": {
            "prediction": referable_prediction,
            "probability": referable_probability,
            "threshold": REFERABLE_THRESHOLD,
            "threshold_source": REFERABLE_THRESHOLD_SOURCE,
            "derived_from_grade": derived_referable,
            "head_grade_disagreement": (
                referable_disagreement
            ),
        },

        "uncertainty": {
            "level": uncertainty_level,
            "conformal_prediction_set": conformal_set,
            "conformal_threshold": CONFORMAL_THRESHOLD,
            "calibration_temperature": (
                CALIBRATION_TEMPERATURE
            ),
            "source": CONFORMAL_SOURCE,
            "note": (
                "Conformal parameters were fitted on "
                "E9 validation predictions only. "
                "External-domain coverage can differ."
            ),
        },

        "reliability": {
            "evidence_score": evidence_score,
            "evidence_threshold": EVIDENCE_THRESHOLD,
            "evidence_reliable": evidence_reliable,
            "evidence_threshold_source": (
                EVIDENCE_THRESHOLD_SOURCE
            ),
            "review_required": review_required,
            "review_reasons": {
                "uncertainty": review_for_uncertainty,
                "low_evidence": review_for_evidence,
                "referable_head_grade_disagreement": (
                    referable_disagreement
                ),
            },
            "note": (
                "Experimental reliability gating. "
                "Not clinically validated."
            ),
        },

        "lesions": {
            "status": "experimental_map_summary",
            "note": (
                "Experimental lesion evidence: values are mean "
                "sigmoid activations of lesion maps and are not "
                "clinically validated lesion probabilities."
            ),
            "activations": lesion_activations,
            "named_activations": {
                LESION_LABELS[key]: value
                for key, value in lesion_activations.items()
            },
        },

        "structures": {
            "optic_disc": {
                "status": "not_implemented",
                "blocker": "Annotations exist in IDRiD, but the frozen E9 checkpoint lacks an OD head and retraining is forbidden by safety constraints."
            },
            "fovea": {
                "status": "not_implemented",
                "blocker": "No verified fovea coordinate/annotation data exists in the local data directory."
            },
            "vessels": {
                "status": "not_implemented",
                "blocker": "The DRIVE dataset is not downloaded (only README exists), so vessel masks are unavailable."
            },
            "neovascularization": {
                "status": "not_implemented",
                "blocker": "No verified neovascularization dataset or annotations exist locally."
            },
            "note": "No structure model is deployed for arbitrary inference; no predictions are fabricated.",
        },

        "explainability": {
            "status": "available",
            "method": "Grad-CAM",
            "target": "predicted_dr_class",
            "target_layer": "encoder.7",
            "target_class": dr_grade,
            "note": (
                "Model-attribution visualization; "
                "not clinically validated lesion localization."
            ),
            "overlay_png_base64": gradcam_overlay,
        },

        "deployment": {
            "image_size": IMAGE_SIZE,
            "device": str(DEVICE),
        },

        "recommendation_status": (
            "review_required"
            if review_required
            else "screening_result_available"
        ),
        "recommendation": (
            "Clinical review recommended; this experimental screening-support output is not a diagnosis."
            if review_required
            else "Screening result available for clinical review; this output is not a diagnosis."
        ),
    }
